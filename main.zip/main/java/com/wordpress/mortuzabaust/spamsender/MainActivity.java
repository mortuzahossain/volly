package com.wordpress.mortuzabaust.spamsender;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView showData;
    String myUrl = "https://userfun.000webhostapp.com/spamsender/api.php";
    String t1, t2 = "";
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.mylist);
        fatchingData();
    }

    void fatchingData() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(myUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                final String[] from = new String[response.length()];
                final String[] to = new String[response.length()];
                final String[] gip = new String[response.length()];
                final String[] message = new String[response.length()];

                for (int i = 0; i < response.length(); i++) {

                    try {

                        JSONObject jsonObject = (JSONObject) response.get(i);
                        from[i] = jsonObject.getString("from_address");
                        to[i] = jsonObject.getString("to_address");
                        gip[i] = jsonObject.getString("ip");
                        message[i] = jsonObject.getString("message");


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

                lv.setAdapter(new ArrayAdapter(getApplicationContext(), R.layout.mylistview, R.id.fromAddressinList, from));

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent intent = new Intent(MainActivity.this, Details.class);
                        intent.putExtra("from", from[position]);
                        intent.putExtra("to", to[position]);
                        intent.putExtra("ip", gip[position]);
                        intent.putExtra("message", message[position]);
                        startActivity(intent);

                    }
                });

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Something Wrong");
            }
        });

        com.wordpress.mortuzabaust.spamsender.AppController.getInstance().addToRequestQueue(jsonArrayRequest);
    }
}
