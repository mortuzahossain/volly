package com.wordpress.mortuzabaust.spamsender;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Details extends AppCompatActivity {


    TextView from, to, ip, message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        from = (TextView) findViewById(R.id.fromaddress);
        to = (TextView) findViewById(R.id.toaddress);
        ip = (TextView) findViewById(R.id.ip);
        message = (TextView) findViewById(R.id.message);


        String _from = getIntent().getStringExtra("from");
        String _to = getIntent().getStringExtra("to");
        String _ip = getIntent().getStringExtra("ip");
        String _message = getIntent().getStringExtra("message");

        from.setText(_from);
        to.setText(_to + "\n");
        ip.setText(_ip + "\n\n");
        message.setText(_message);
    }
}